# Play Music API Running on Raspberry Pi

1. Update the path of the music file in play-music.py
2. Expose the API externally using Local Tunnel (https://github.com/localtunnel/localtunnel) or Ngrok (https://ngrok.com/)
3. Note down the URL. This will need to be updated in the calling Lambda function variable

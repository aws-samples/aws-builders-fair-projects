from flask import Flask, json
import vlc
import time
import threading

api = Flask(__name__)

player = vlc.MediaPlayer("music-file.mp3")

@api.route('/play-music', methods=['GET'])
def play_music():
  def start_music():
    player.play()
    time.sleep(120)
    player.stop()

  thread = threading.Thread(target=start_music)
  thread.start()
  return 'started'

@api.route('/stop-music', methods=['GET'])
def stop_music():
    player.stop()
    return 'stopped'


if __name__ == '__main__':
    api.run()
